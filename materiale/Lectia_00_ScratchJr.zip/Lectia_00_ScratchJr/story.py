"""Native ScratchJr scenes: visible destinations, objects and consequences."""
from copy import deepcopy

def make_story(actor,script,b,label,repeat):
    def a(key,asset,x,y,*scripts,scale=.25,name=None,shown=True):
        return actor(key,asset,x,y,*scripts,scale=scale,name=name,shown=shown)
    def header(text):return [label(text,240,28,24)]
    cast=[('iepuras','Rabbit',.24),('pui','Chicken',.24),('catel','Dog',.20),('rata','Duck',.32),('pasare','Bird',.28)]

    invitation={'background':'Park.svg','focus':'iepuras','build':[['iepuras',0]],'texts':header('1. Îl chemăm pe cățel'),'sprites':[
        a('casa','House3',380,140,scale=.5,name='Casa cățelului'),
        a('gard','Fence',240,288,script('ontouch',b('message','Red')),scale=.65,name='Gardul de ocolit'),
        a('iepuras','Rabbit',120,288,
          script('onflag',b('home'),b('up',3),b('forward',10),b('down',3)),
          script('onmessage',b('stopmine'),b('home'),b('say','Ocolesc gardul!'),color='Red'),scale=.22,name='Iepurașul'),
        a('catel','Dog',360,288,script('ontouch',b('playsnd','pop.mp3'),b('say','Vin la picnic!'),b('wait',10),b('gotopage',2)),scale=.24,name='Cățelul')
    ]}

    orchard={'background':'Park.svg','focus':'mar3','build':[['mar3',0],['mar4',0],['mar5',0]],'texts':header('2. Mere pentru fiecare'),'sprites':[
        a('pom','Tree1',240,160,scale=.65,name='Mărul'),
        a('masa','Table',240,274,
          script('onclick',b('say','Poftiți la masă!'),b('gotopage',3)),scale=.6,name='Masa de picnic'),
        a('mar1','Apple',144,190,scale=.25,name='Măr pe masă 1'),
        a('mar2','Apple',336,190,scale=.25,name='Măr pe masă 2'),
        a('mar3','Apple',192,94,script('onclick',b('home'),b('down',4),b('playsnd','pop.mp3')),scale=.25,name='Mărul de pe ramura stângă'),
        a('mar4','Apple',240,118,script('onclick',b('home'),b('down',3),b('playsnd','pop.mp3')),scale=.25,name='Mărul de pe ramura joasă'),
        a('mar5','Apple',288,94,script('onclick',b('home'),b('down',4),b('playsnd','pop.mp3')),scale=.25,name='Mărul de pe ramura dreaptă')
    ]}
    for (key,asset,scale),(x,y) in zip(cast,[(72,270),(135,325),(408,270),(240,325),(345,325)]):
        orchard['sprites'].append(a(key,asset,x,y,scale=scale,name=key.capitalize()))

    picnic={'background':'Park.svg','focus':'iepuras','build':[['iepuras',0]],'texts':header('3. Mâncăm împreună'),'sprites':[
        a('casa','House3',408,128,scale=.5,name='Adăpostul de lângă masă'),
        a('masa','Table',264,274,scale=.6,name='Masa de picnic'),
        a('soare','Sun',80,68,script('onmessage',b('show'),color='Orange'),
          script('onmessage',b('hide'),color='Purple'),scale=.4,name='Soarele'),
        a('nor','Thundercloud',72,122,
          script('onmessage',b('hide'),b('home'),color='Orange'),
          script('onmessage',b('show'),b('forward',4),b('say','Vine ploaia!'),b('gotopage',4),color='Purple'),
          scale=.4,name='Norul de ploaie',shown=False)
    ]}
    xs=[168,216,264,312,360]
    for i,x in enumerate(xs):
        picnic['sprites'].append(a('mar'+str(i+1),'Apple',x,214,
            script('onmessage',b('home'),b('same'),b('show'),color='Orange'),
            script('onmessage',repeat(2,b('shrink',2),b('playsnd','pop.mp3'),b('wait',5)),b('hide'),
                   color='Red' if i<2 else 'Blue'),scale=.4,name='Măr pentru '+cast[i][0]))
    for i,((key,asset,scale),x) in enumerate(zip(cast,xs)):
        programs=[]
        if key=='iepuras':programs.append(script('onflag',b('message','Orange'),b('say','Poftă bună!'),
            b('message','Red'),b('wait',50),b('message','Blue'),b('wait',20),b('message','Purple')))
        programs.append(script('onmessage',b('home'),b('up',3),color='Orange'))
        picnic['sprites'].append(a(key,asset,x,314,*programs,scale=scale*.85,name=key.capitalize()))

    rain={'background':'Park.svg','focus':'iepuras','build':[['iepuras',0]],'texts':header('4. Toți la adăpost!'),'sprites':[
        a('casa','House3',408,128,script('onmessage',b('playsnd','pop.mp3'),color='Purple'),scale=.5,name='Adăpostul'),
        a('masa','Table',264,274,scale=.6,name='Masa de picnic'),
        a('soare','Sun',80,68,script('onmessage',b('hide'),color='Red'),script('onmessage',b('wait',5),b('show'),color='Purple'),scale=.4,name='Soarele',shown=False),
        a('nor','Thundercloud',168,122,
          script('onclick',b('home'),b('forward',4),b('message','Red')),
          script('onmessage',b('back',4),b('hide'),color='Purple'),scale=.4,name='Norul de ploaie')
    ]}
    for i,(key,asset,scale) in enumerate(cast):
        x=168+48*i
        moves=[b('forward',10-2*i),b('up',2),b('hide')]
        if i==0:moves += [b('wait',10),b('message','Blue')]
        if i==2:moves += [b('message','Purple')]
        rain['sprites'].append(a(key,asset,x,242,script('onmessage',*moves,color='Red' if i<2 else 'Blue'),scale=scale*.85,name=key.capitalize()))

    shortcut=deepcopy(invitation)
    shortcut['texts']=header('Rezervă: ocolul cu Repetă')
    cat=next(s for s in shortcut['sprites'] if s['id']=='iepuras')
    cat['scripts'][0]=script('onflag',b('home'),b('up',3),repeat(2,b('forward',5)),b('down',3))
    dog=next(s for s in shortcut['sprites'] if s['id']=='catel')
    dog['scripts'][0]=script('ontouch',b('playsnd','pop.mp3'),b('say','Ai găsit drumul!'),b('hop',1),b('forward',3))

    dance={'background':'Park.svg','focus':'iepuras','build':[], 'texts':header('Rezervă: dansăm și înghețăm'),'sprites':[]}
    for i,(key,asset,scale) in enumerate(cast):
        programs=[]
        if i==0:programs.append(script('onclick',b('message','Red')))
        if i==4:programs.append(script('onclick',b('message','Blue')))
        programs.append(script('onmessage',b('hop',1),b('wait',5),b('forever'),color='Red'))
        if i<2:programs.append(script('onmessage',b('stopmine'),color='Blue'))
        dance['sprites'].append(a(key,asset,72+84*i,245,*programs,scale=scale*1.3,name=key.capitalize()))
    return [invitation,orchard,picnic,rain],shortcut,dance
