# Lecția 0 — Picnicul întrerupt de ploaie

**50 de minute · 6–7 ani · laptop și proiector · lucrăm în ScratchJr**

Cinci prieteni pregătesc un picnic. Îl chemăm pe cățel, culegem mere pentru fiecare și îi poftim la masă. Norul de furtună schimbă planul: trebuie să-i conducem pe toți la adăpost.

Adunările și scăderile ne ajută să hotărâm ce programăm: câte mere mai trebuie culese, pentru cine le păstrăm pe cele rămase și câți prieteni mai trebuie chemați în casă. Copiii răspund arătând obiectele din scenă, apoi construiesc sau pornesc acțiunea potrivită.

[Desfășurătorul lecției](https://scoalaaltfelexploratori.github.io/Pregatitoare1/scratchjr/lectia-0/index.html) · [Toate lecțiile](https://scoalaaltfelexploratori.github.io/Pregatitoare1/scratchjr/index.html)

## Ghidul profesorului și toate soluțiile

[**Ghidul profesorului — ce spui și ce faci, pas cu pas**](Ghid_profesor.md)

Fiecare activitate are un model ScratchJr complet, editabil. Selectează orice personaj din stânga ca să-i vezi programul.

- **Cele patru scene principale:** [soluția completă a poveștii](proiecte/00_Laboratorul_ScratchJr.sjr). Pentru lucru live: [Construim împreună](proiecte/01_Construim_impreuna.sjr).
- **Rezerva 1 — Ocolul cu Repetă:** [soluția rezolvată](proiecte/02_Rezerva_Contact.sjr).
- **Rezerva 2 — Dansăm și înghețăm:** [soluția rezolvată](proiecte/03_Rezerva_Statui.sjr).
- **Rezerva 3 — Scuturăm pomul:** [soluția rezolvată](solutii/03_Scuturam_pomul.sjr).
- **Rezerva 4 — Cei trei, primii:** [soluția rezolvată](solutii/04_Cei_trei_primii.sjr).
- **Rezerva 5 — A trecut ploaia:** [soluția rezolvată](solutii/05_A_trecut_ploaia.sjr).

Soluțiile rezervelor au câte o singură pagină. Cele trei provocări noi se pot construi pe paginile 2–4 ale poveștii; modelele separate sunt pentru demonstrație și verificare.

## Pregătire

1. Descarcă [proiectul complet](proiecte/00_Laboratorul_ScratchJr.sjr) și [varianta de construit](proiecte/01_Construim_impreuna.sjr). Nu dezarhiva fișierele `.sjr`.
2. Deschide [ScratchJr în browser](https://richiesamlie.github.io/ScratchJr-Desktop-Reborn/play/), portul comunitar ScratchJr Desktop Reborn. În galerie: **Open → fișierul descărcat**.
3. Deschide **L00 Construim picnicul** pentru lucru cu copiii. **L00 Picnicul intrerupt de ploaie** este modelul complet.
4. Apasă titlul proiectului, dă copiei tale un nume (de exemplu **Picnicul clasei**) și confirmă cu bifa. Lucrează în această copie.
5. Verifică sunetul și proiectorul. Arată editorul când construiți codul, apoi mărește scena pentru a urmări acțiunea.

Importul se face numai pe laptopul profesorului. Copiii nu au nimic de copiat pe tablete. Toate imaginile și sunetul Pop sunt din biblioteca ScratchJr.

**Ai deja o copie importată?** Descarcă și importă din nou proiectul complet și varianta de construit pentru a primi invitația mesei din pagina 2. Copiile existente în ScratchJr nu se actualizează singure; păstrează separat lucrul tău.

## Cum lucrăm

Copiii descriu ce trebuie să se întâmple, aleg blocurile și prezic rezultatul. Un copil vine la laptop și adaugă o instrucțiune. Selectăm personajul **în stânga** pentru cod; îl apăsăm **pe scenă** pentru pornire. Grila ajută la numărarea pașilor, apoi o ascundem. La blocurile cu plic, alegem culoarea din săgeata mică de sub bloc. Dacă plicul nu se vede imediat în browser, selectarea culorii îl redesenează.

### 1. Îl chemăm pe cățel · 5–13 minute

Cățelul așteaptă lângă casă. Gardul se află între el și iepuraș. **Cum ajungem la prieten fără să trecem prin gard?**

Iepuraș: **La steag → Înapoi acasă → Sus 3 → Dreapta 10 → Jos 3.**

Pornim cu **steagul verde**. Copiii urmăresc cele trei laturi ale ocolului. La contactul cu gardul, iepurașul revine la plecare. Când atinge cățelul, acesta răspunde „Vin la picnic!”, se aude Pop și se deschide pagina cu mere. Aceste reacții sunt deja pregătite în varianta de construit.

### 2. Mere pentru fiecare · 13–23 minute

Vedem **cinci prieteni**, **două mere pe masă** și **trei mere în copac**. **Câte mai culegem ca fiecare să primească unul?** Pentru cinci prieteni ne trebuie cinci mere; avem deja două, deci lipsesc **5 − 2 = 3**. Copiii aleg cele trei fructe pentru care vor construi programe.

Construim la cele trei mere din copac: **La apăsare → Înapoi acasă → Jos → Pop**. Merele de pe ramurile laterale coboară **4** pași; cel din mijloc coboară **3**. Numărul merelor alese și distanța parcursă de fiecare sunt lucruri diferite. Pornim pe rând și verificăm că toate ajung pe masă: **2 + 3 = 5**, câte unul pentru fiecare prieten.

**Suntem gata să-i chemăm?** După ce merele au ajuns, un copil apasă **blatul mesei pe scenă**. Masa afișează „Poftiți la masă!”, apoi deschide pagina 3. Programul ei este deja pregătit în ambele proiecte principale: **La apăsare → Spune „Poftiți la masă!” → Mergi la pagina 3**. Îl putem arăta sau reconstrui împreună. Invitația apare într-un balon de text; o citim cu voce tare.

### 3. Poftiți la masă! · 23–31 minute

După invitația mesei apare pagina 3. **Înainte de servire:** dacă butonul de sus este Stop roșu, îl apăsăm, apoi apăsăm steagul verde care apare în locul lui. Dacă este deja verde, îl apăsăm direct. Această pornire activează contactele merelor în versiunea pentru browser. Apoi apăsăm **iepurașul pe scenă**, o singură dată.

Iepurașul și puiul merg la masă, ating câte un măr și se întorc. **Cine n-a mâncat încă? Ajung merele rămase pentru ei?** Sunt **5 − 2 = 3 mere** pentru cățel, rață și pasăre. Copiii îi identifică și aleg mesajul albastru care îi cheamă. A doua servire așteaptă apăsarea cățelului, deci putem discuta pe îndelete.

Iepuraș: **La apăsare → Trimite roșu.** Cățel: **La apăsare → Trimite albastru.**

Programele de primire sunt pregătite: roșu cheamă primii doi; albastru îi cheamă pe ceilalți trei. Fiecare face **Sus 4 → Așteaptă 5 → Jos 4**. Merele au **La contact → Pop → Ascunde**. Ascunderea înseamnă că fructul a fost mâncat, după atingere.

Un copil apasă cățelul o singură dată. Ultimii trei mănâncă: **3 − 3 = 0 mere**. Verificăm că toți cinci au primit câte unul; masa s-a încheiat. Apăsăm **Stop**, apoi alegem **pagina 4**: vremea se schimbă.

### 4. Toți la adăpost! · 34–46 minute · dificil

Norul se apropie. Casa este adăpostul; cei cinci prieteni sunt afară. **După ce intră iepurașul și puiul, pe cine mai chemăm?** Rămân **5 − 2 = 3 afară**: cățelul, rața și pasărea. Înainte de pornire, copiii arată cele trei personaje și verifică cine primește mesajul albastru. Nimeni nu trebuie uitat.

Completăm programul iepurașului: **La roșu → Dreapta 8 → Sus 4 → Ascunde → Așteaptă 10 → Trimite albastru.** Ascunde se folosește abia la ușa casei. Pornim apăsând **norul**.

Puiul intră împreună cu iepurașul. Mesajul albastru îi pornește pe ceilalți trei. Urmărim lanțul până la capăt: **3 − 3 = 0 afară**, deci toți sunt la adăpost. Prietenii sunt în casă; numărăm cine mai are nevoie de ajutor. Cățelul, care are cel mai lung drum din acest grup, trimite mov la sosire și pornește finalul scenei: norul pleacă, revine soarele și se aude Pop.

Arată și programul cățelului. **De ce trimitem mesajul după deplasare?** Dacă îl trimitem înainte, următoarea acțiune începe prea devreme. Provocare suplimentară: calculați drumul celorlalți — 6, 4, 2 și 0 pași la dreapta, apoi câte 4 în sus.

## Ritmul întâlnirii

- **0–5:** povestea, scena, personajele, blocurile și paginile.
- **5–31:** primele trei scene, cu un copil diferit la fiecare intervenție.
- **31–34:** pauză — doi copii mimează primii invitați, apoi vin ceilalți trei.
- **34–46:** puzzle-ul dificil al adăpostului.
- **46–50:** reluăm o scenă; un copil explică de ce ordinea blocurilor contează.

## Dacă terminăm mai repede

Avem cinci opțiuni, aproximativ **25–35 de minute de rezervă** în total. Alegem una sau două, după timpul rămas; nu trebuie parcurse toate. Duratele includ propunerile copiilor, construirea și testarea.

### Două proiecte de rezervă

- [Același drum, mai puțin cod](proiecte/02_Rezerva_Contact.sjr) · 5–7 minute: ocolim același gard, dar înlocuim Dreapta 10 cu **Repetă 2 [Dreapta 5]**. Pornim cu steagul. Comparăm unde ajunge iepurașul și numărăm 5 + 5.
- [Dansăm și înghețăm](proiecte/03_Rezerva_Statui.sjr) · 5–7 minute: iepurașul pornește dansul celor cinci. Pasărea îi îngheață pe primii doi; trei continuă. Găsiți programele **Repetă mereu** și **Oprește**. Modificați cine primește semnalul de oprire.

### 3. Scuturăm pomul o singură dată · 4–6 minute

**Misiune:** „Prietenii așteaptă. Putem culege toate cele trei mere cu o singură apăsare pe copac?”

Lucrăm pe pagina 2, după ce am construit coborârea merelor. Adăugăm copacului **La apăsare → Trimite roșu**. La fiecare dintre cele trei mere din copac, înlocuim pornirea La apăsare cu **La mesaj roșu**; păstrăm Înapoi acasă, coborârea și Pop. Cele două mere de pe masă rămân fără program.

Apăsăm Reset Characters, apoi copacul o singură dată. Cele trei mere coboară pe masă. Copiii verifică **2 + 3 = 5** și explică de ce același mesaj poate porni trei programe. Pot veni trei copii, fiecare pentru câte un măr.

În povestea principală, apăsăm apoi masa pentru a continua la pagina 3. În soluția R3 separată, masa afișează aceeași invitație și rămânem pe unica pagină a proiectului.

### 4. Cei trei prieteni au ajuns primii · 4–6 minute

**Misiune:** „De data aceasta, cățelul, rața și pasărea mănâncă primii. Iepurașul trebuie să-i cheme, iar cățelul îi va chema apoi pe ceilalți doi.”

Pe pagina 3, schimbăm mesajul trimis la apăsarea iepurașului în **albastru**, iar pe cel trimis de cățel în **roșu**. Păstrăm programele care primesc mesajele.

Pornim steagul, apăsăm iepurașul și așteptăm revenirea celor trei. **Pentru cine păstrăm cele 5 − 3 = 2 mere?** Copiii arată iepurașul și puiul și aleg mesajul roșu pentru ei. Apăsăm cățelul: **2 − 2 = 0 mere**, iar fiecare prieten a mâncat o singură dată. Doi copii pot modifica pe rând câte un buton.

### 5. A trecut ploaia! · 7–9 minute · dificil

**Misiune:** „Soarele a revenit. O singură apăsare pe el trebuie să scoată toți prietenii din casă și să-i ducă la locurile lor.”

Pe pagina 4, adăugăm soarelui **La apăsare → Trimite verde**. Fiecare prieten primește un program nou: **La verde → Arată → Jos 4 → Stânga**. Păstrăm toate programele de intrare în casă.

- Iepurașul: **Stânga 8**.
- Puiul: **Stânga 6**.
- Cățelul: **Stânga 4**.
- Rața: **Stânga 2**.
- Pasărea: programul se termină după **Jos 4**; locul ei este chiar în fața casei.

Copiii urmăresc traseul de intrare și deduc drumul de întoarcere. Întâi rulăm furtuna până se încheie, apoi apăsăm soarele **o singură dată**. Verificăm că toți cinci sunt vizibili, la locurile de plecare. Pentru o nouă rundă: Stop, Reset Characters, apoi norul.

Aceste trei provocări se construiesc live în copia proiectului principal, folosind obiectele existente. Nu necesită alte fișiere sau imagini. Dacă au rămas doar câteva minute, alege o singură modificare și lasă un copil să explice rezultatul clasei.

## Reluare și salvare

Apasă **Stop**, apoi **Reset Characters** înainte să reiei o scenă. Resetarea aduce înapoi merele și personajele ascunse. Întâlnirea cu cățelul deschide pagina 2; apăsarea mesei din pagina 2 afișează invitația și deschide pagina 3. După servire, apasă Stop și alege pagina 4 din dreapta. Miniaturile rămân disponibile pentru reluarea oricărei scene; așteaptă încheierea acțiunii înainte să schimbi pagina manual.

Pentru salvare, întoarce-te în galeria ScratchJr și redeschide copia ta ca să verifici blocurile. Păstrează fișierele descărcate pentru o copie curată. În rezerve, oprește dansul înainte de a ieși.

[Verificarea proiectelor](verificare/README.md)
