# Verificare — Picnicul întrerupt de ploaie

12 noiembrie 2026. Proiecte native `.sjr`, importate prin Open și rulate în ScratchJr Desktop Reborn, portul comunitar pentru browser.

| Probă | Rezultat urmărit |
| --- | --- |
| Ocolul gardului | Iepurașul ocolește gardul, atinge cățelul, se aude Pop și se deschide pagina 2. |
| Drum direct, copie separată de test | Gardul declanșează întoarcerea iepurașului la plecare; pagina rămâne 1. Copia nu se distribuie elevilor. |
| Merele | Trei mere coboară din copac la aceeași înălțime cu cele două de pe masă. Trei Pop. |
| Masa | Cele cinci mere rămân vizibile după pornire. Primul grup mănâncă exact două; al doilea, cele trei rămase. Contactele produc 2, respectiv 3 Pop. |
| Adăpostul | Primii doi ajung la ușă înainte să pornească ceilalți trei. Toți cinci dispar la ușă; apoi norul pleacă, soarele revine și se aude Pop. |
| Repetarea | Repetă 2 [Dreapta 5] produce același ocol. Cățelul răspunde o singură dată și se dă la o parte. |
| Statuile | Toți cinci dansează. Pasărea îi oprește pe primii doi; ceilalți trei continuă. |
| Construim împreună | Cele patru pagini se importă; rămân numai declanșatoarele la sarcinile de construit. Un bloc adăugat manual a fost conectat, schimbat la 4 și rulat. Salvarea a fost verificată separat într-o copie redenumită, cu blocul Jos 1. |

Înregistrări: [ocol](01_ocolul.json), [mere](02_mere.json), [masa înainte de contact](03_masa_initial.json), [primii doi](04_masa_doi.json), [ceilalți trei](05_masa_trei.json), [adăpost](06_adapost.json), [repetare](07_repetare.json), [statui](08_statui.json), [gard](09_gard.json), [construcție](10_constructie.json).

Înregistrările provin dintr-o copie locală a aplicației publice cu un observator pentru transformările scenei și ieșirea audio. Motorul ScratchJr nu este modificat. Proiectul final a fost parcurs și în aplicația publică. Testarea audio verifică semnalul produs de browser, nu difuzorul fizic.

În acest port, scena cu contact trebuie pornită cu steagul. În scena mesei, programul pregătit al mesei menține scena activă în timp ce profesorul discută și apasă personajele. Această particularitate este tratată și în ghid. La prima încărcare, unele pictograme de plic pot rămâne goale în acest port, deși mesajele rulează; alegerea culorii din meniul blocului le redesenează.

Arhivele sunt verificate pentru JSON valid, identificatori unici, destinații existente și maximum patru pagini. Nu conțin personaje sau decoruri personalizate. Rabbit, Chicken, Dog, Duck, Bird, House3, Fence, Table, Tree1, Apple, Thundercloud, Sun, Park și Pop sunt resurse incluse în ScratchJr. Hashurile fișierelor sunt în `lesson.json`.

Verificarea funcțională de aici este în browser; nu reprezintă un test pe tabletele Android ale clasei. Website-ul are și verificări automate pentru proiecte și navigare, inclusiv toate cele zece lecții și secțiunea Robo.

[Scena din aplicația publică](picnicul-scratchjr.png) · [Blocul adăugat manual](constructie-manuala.png) · [Copia salvată și redeschisă](constructie-salvata.png)

Cele zece înregistrări au trecut verificările din `check_results.py`. Cele nouă teste automate pentru arhivele lecției și navigarea website-ului au trecut.

La prima probă, copia proaspăt importată nu a păstrat blocul după ieșire. Redenumirea proiectului înainte de lucru a permis salvarea și redeschiderea cu blocul conectat. Ghidul include acest pas; fișierele originale rămân disponibile pentru reimport.

## Cele trei provocări suplimentare

Verificate pe 12 noiembrie 2026, într-o copie separată a proiectului complet, importată în aplicația publică ScratchJr Desktop Reborn. Copia aplică exact modificările de blocuri descrise în ghid. Cele patru fișiere inițiale nu au fost schimbate.

- O apăsare pe copac coboară toate cele trei mere la înălțimea celor două de pe masă.
- După schimbarea comenzilor celor două personaje, iepurașul cheamă întâi grupul de trei: rămân două mere. Cățelul cheamă apoi grupul de doi: nu mai rămân mere.
- După furtună, apăsarea soarelui îi arată pe toți cinci și îi readuce la pozițiile lor de plecare. Norul rămâne ascuns.

[Stările observate în browser](11_bonus.json). Provocările se construiesc live în proiectul principal, fără imagini sau fișiere suplimentare.

## Soluții descărcabile și ghidul profesorului

Fiecare dintre cele trei bonusuri are acum și un fișier `.sjr` separat în `solutii/`, cu o singură pagină și toate programele completate. Fișierele finale au fost importate și rulate individual în aplicația publică:

- **R3 — Scuturăm pomul:** o apăsare pe copac aduce toate cele trei fructe la nivelul mesei.
- **R4 — Cei trei, primii:** steagul, apoi iepurașul lasă două mere; cățelul pornește a doua servire și rămân zero.
- **R5 — A trecut ploaia:** norul îi conduce pe toți la adăpost; după încheierea furtunii, soarele îi readuce pe toți cinci la coordonatele lor inițiale.

[Rezultatele fișierelor finale](12_solutii.json). Arhivele au structură validă, iar hashurile tuturor celor șapte proiecte sunt în `lesson.json`. Cele patru fișiere inițiale sunt identice cu versiunile testate anterior.

[Ghidul profesorului](../Ghid_profesor.md) acoperă cele patru scene și toate cele cinci rezerve: formularea misiunii, întrebări, blocuri, pornire, rezultat și verificări practice. Versiunea pentru website poate fi tipărită din browser.

## Scăderi care ajută povestea — 13 noiembrie 2026

Ghidul și pagina lecției leagă acum scăderile de decizii concrete: culegem cele trei mere lipsă pentru cinci prieteni, păstrăm merele rămase pentru cei neserviți și verificăm cine mai trebuie adăpostit. Rezerva R4 include și servirea în ordinea trei, apoi doi. Durata lecției și programele ScratchJr rămân aceleași; toate cele șapte fișiere `.sjr` au fost comparate cu versiunile verificate anterior și sunt identice.

Modelul complet a fost redeschis în aplicația publică ScratchJr Desktop Reborn și au fost rulate scenele 2–4:

- Culesul: cele trei mere din pom coboară la aceeași înălțime cu cele două de pe masă; sunt cinci în total.
- Servirea: după iepuraș și pui rămân exact trei mere, vizibile cât discutăm; după apăsarea cățelului și servirea celorlalți trei rămân zero.
- Adăpostul: după lanțul pornit de nor, toți cinci sunt ascunși la ușă, norul este ascuns și soarele este vizibil.

[Stările scenei observate în browser](13_scaderi.json). La această revizie nu au fost rerulate cele cinci rezerve și nu s-a făcut un nou test Android. Cele nouă teste pentru lecție și navigare au trecut; verificarea locală a site-ului a găsit 353 de adrese valide, iar arhiva ZIP conține ghidurile actualizate. Ghidul a fost verificat și vizual în browser.

## Invitația mesei — 15 noiembrie 2026

În proiectul complet și în Construim împreună, masa din pagina 2 are acum **La apăsare → Spune „Poftiți la masă!” → Mergi la pagina 3**. Programul este complet și în varianta de construit. Copiii verifică mai întâi că au cules merele, apoi apasă blatul pentru a continua povestea. Masa nu verifică automat numărul merelor.

Cele trei fișiere modificate au fost importate separat în aplicația publică ScratchJr Desktop Reborn:

- **Povestea completă:** traseul ajunge în pagina 2; cele trei mere coboară, iar apăsarea mesei afișează invitația înainte să deschidă pagina 3, cu toate cele cinci mere vizibile.
- **Construim împreună:** invitația și trecerea la pagina 3 funcționează direct; programele de construit rămân necompletate. La această probă s-a verificat comanda mesei, fără reconstruirea celor trei programe ale merelor.
- **R3 — Scuturăm pomul:** apăsarea copacului coboară cele trei mere; masa afișează invitația și rămâne pe unica pagină. Soluția separată nu conține o trimitere la pagina 3.

**Particularitate găsită în browser:** după schimbarea automată la pagina 3, personajele se deplasau, dar merele nu reacționau la contact. Apăsarea **Stop → steag verde**, înainte de chemarea prietenilor, activează contactele. Cu acest pas, primul grup lasă trei mere și al doilea zero. Ghidul și pagina lecției includ pornirea explicită; programele de servire sunt cele existente.

[Rezultatele observate](14_invitatia_mesei.json) · [Invitația vizibilă în aplicație](invitatia-mesei.png).

Cele nouă teste pentru proiecte și navigare au trecut. Cele șapte arhive `.sjr` sunt valide și au hashurile actualizate în `lesson.json`; patru dintre ele sunt neschimbate. Verificarea de aici este pentru browser, nu pentru aplicația Android sau Desktop instalată. Nu au fost rerulate rezervele R1, R2, R4 și R5 la această revizie.
