# Soluțiile lecției 3

Numai pentru profesor. Copiii creează proiectele în ScratchJr, folosind Dog, Rabbit și Park din bibliotecă. Arată întâi ținta și oferă indicii; soluțiile nu sunt fișe de copiat de la început. Fiecare program de mai jos începe cu steagul verde.

| Misiune și fișier | Iepure | Câine |
| --- | --- | --- |
| [1. Câinele primul](01_Cainele_primul.sjr) | Lent, dreapta 12 | Repede, dreapta 12 |
| [2. Drumul lung](02_Drum_lung_castigator.sjr) | Repede, dreapta 12 | Lent, dreapta 6 |
| [3. Depășirea](03_Depasirea.sjr) | Lent, dreapta 2, repede, dreapta 10 | Mediu, dreapta 12 |
| [R1. Împreună](04_Rezerva_Sosire_impreuna.sjr) | Repede, dreapta 12 | Mediu, dreapta 6 |
| [R2. Virajul](05_Rezerva_Virajul_expres.sjr) | Lent, dreapta 4, repede, sus 4, mediu, dreapta 4 | Fără program |

M1 și M3 pornesc din coloana 4; M2 și R1 dau câinelui un avans până la coloana 10. Iepurele rămâne în coloana 4. Sosirea curselor este coloana 16. Iepurele este pe rândul 10, câinele pe rândul 4.

R2: iepure (4, 5) → (8, 5) → (8, 9) → (12, 9); câinele stă la (16, 4). Nicio imagine de traseu nu trebuie importată. Cele trei săgeți au câte 4 pași.

Pentru M3 sunt acceptate alte împărțiri pozitive ale celor 12 pași dacă iepurele începe lent, câinele conduce la început, apoi iepurele trece pe repede și câștigă. Nu este corect să modifice drumul câinelui sau să reducă distanța totală. Pentru R1 acceptăm sosirea vizual aproape simultană, fără cronometru.

Fiecare program alege viteza explicit la început. Resetează înainte de o cursă completă; nu în timpul ei. [Raportul](../../verificare/README.md) precizează ce a fost testat în browser și ce rămâne de verificat pe Lenovo.
