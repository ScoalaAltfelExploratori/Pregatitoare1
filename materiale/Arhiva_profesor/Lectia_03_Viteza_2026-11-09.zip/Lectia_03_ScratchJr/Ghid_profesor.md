# Lecția 3 Curse cu surprize

50 de minute pentru copii de 6-7 ani. Trei misiuni în timpul de bază, inclusiv o provocare dificilă. Două puzzle-uri de rezervă adaugă aproximativ 14-18 minute de activitate, numai dacă rămâne timp sau pentru copiii care termină repede.

## Ce este nou

Folosim **blocul portocaliu Set Speed / Viteză** pentru a construi curse cu rezultate precise. Lecția 1 a lucrat întâlnirea și revenirea; lecția 2 a introdus Repeat. Acum anticipăm ordinea sosirii, un avans și o depășire. Nu cerem sărituri, întoarceri sau bucle. Viteza schimbă ritmul; numărul de pe săgeată schimbă distanța.

Copiii creează programe pentru ținte noi, fără să copieze intenționat greșeli. Profesorul citește cerința și arată rezultatul dorit prin gesturi; nu proiectează soluția completă înaintea încercării. Nu folosim cronometru sau calcule de viteză.

## Pregătire fără fișiere pe tablete

ScratchJr este deja instalat. Deschidem un proiect nou, adăugăm **Dog** și **Rabbit**, eliminăm pisica inițială, apoi alegem **Park**. Toate sunt resurse incluse în aplicație. Nu sunt necesare descărcări, importuri sau personaje desenate. Fundalul alb este acceptat dacă alegerea parcului consumă timp. Nu schimbăm dimensiunile personajelor.

Pornește grila din bara scenei. Pe grila afișată, iepurele începe la **(4, 10)**, iar câinele la **(4, 4)**: numărul de jos este coloana, cel din stânga este rândul. Cele două trasee sunt paralele. Sosirea este **coloana 16** pentru amândoi; comparăm centrele personajelor, nu nasul sau coada. Nu desenăm o linie și nu adăugăm un al treilea personaj.

Copiii pot poziționa aproximativ pe grilă. Numărăm spațiile dintre coloane: de la 4 la 16 sunt 12 pași. Dacă starturile sunt inexacte, potrivim mai întâi pozițiile. Precizia la pixel nu este obiectivul lecției.

## Demonstrația mecanismului

Selectează categoria portocalie, apoi blocul **Viteză**, cu personajul care aleargă. Trage-l după steagul verde. Atinge pictograma mică din partea de jos a blocului și alege lent, mediu sau repede. Arată cele trei opțiuni în aplicație. Acestea nu sunt distanțe și nu se introduc din tastatura numerică a săgeții.

Construiește doar pe iepure: steag, lent, dreapta 3, repede, dreapta 3. Întreabă ce s-a schimbat la mijloc. A doua viteză se aplică acțiunilor următoare ale aceluiași personaj și rămâne activă până la alt bloc Viteză. Câinele are propriul program și propria viteză.

La fiecare program punem explicit viteza înainte de prima deplasare. Înainte de probă apăsăm resetarea personajelor, apoi **o singură dată steagul verde de sus**. Nu pornim separat blocurile galbene și nu intervenim în timpul cursei. Nu ne bazăm pe resetare pentru alegerea vitezei.

<!-- pagebreak -->
## Cele 50 de minute

| Minute | Activitate | Rolul profesorului |
| --- | --- | --- |
| 0-5 | Predicție și demonstrație | Arată schimbarea de viteză pe o secvență scurtă. |
| 5-11 | Scena și noul bloc | Proiect nou, grilă, două personaje, probarea selectorului de viteză. |
| 11-20 | Misiunea 1 | Două viteze, același drum; câinele trebuie să ajungă primul. |
| 20-29 | Misiunea 2 | Câinele primește avans; iepurele trebuie să câștige. |
| 29-32 | Pauză | Copiii mimează lent și repede, fără întrecere fizică. |
| 32-45 | Misiunea dificilă | Start lent, accelerare și depășire. Oferă indicii pe rând. |
| 45-50 | Explicăm și salvăm | Demonstrații în perechi; galerie, redeschidere și o nouă probă. |

Rezervele nu sunt introduse obligatoriu în acest orar. Un copil care termină poate primi cartonașul R1; apoi R2 dacă mai are timp. Dacă întreaga clasă merge repede, folosește timpul câștigat din misiuni pentru o rezervă. Păstrează pauza și ultimele cinci minute. Dacă pregătirea durează, construiește misiunea 1 împreună și păstrează misiunea dificilă pentru toți.

## Misiunea 1 Câinele ajunge primul

**Cerință:** „Pornesc împreună din coloana 4. Amândoi merg 12 pași spre dreapta și se opresc în coloana 16. Alege viteze diferite astfel încât câinele să ajungă primul.”

Fiecare personaj primește steag, un bloc Viteză și o săgeată dreapta. Copiii aleg vitezele. Întreabă înaintea rulării cine cred că va sosi primul și unde se va opri celălalt. Soluția profesorului: iepure lent, câine repede; amândoi dreapta 12. Sunt acceptate și alte două viteze care respectă ordinea.

**Reușită:** câinele ajunge primul, iepurele după el; amândoi rămân la aceeași coloană. **Indicii:** „Cine trebuie să fie mai rapid?”, „Numărul de pe săgeată este viteză sau drum?”. Copilul poate indica blocul responsabil.

## Misiunea 2 Drumul lung poate câștiga?

**Cerință:** „Câinele pornește din coloana 10 și are numai 6 pași. Iepurele pornește tot din 4 și are 12 pași. Sosirea rămâne 16. Construiește cursa în care iepurele câștigă.”

Mutăm câinele înaintea probei la (10, 4) și adaptăm programul la noua distanță. Iepurele rămâne la (4, 10). Copilul alege vitezele, câte una per personaj. Fără așteptare, ocoluri, salt la Acasă sau schimbări ale distanțelor. Soluție: iepure repede, dreapta 12; câine lent, dreapta 6.

**Reușită:** iepurele ajunge primul în coloana 16, deși are drumul mai lung. **Indicii:** „Cine are mai mult drum?”, „Cum îl ajutăm fără să-l mutăm?”. Dacă ajung împreună, ținta încă nu este atinsă; copilul alege o diferență de viteză mai mare. Aceasta este ajustarea propriei creații.

<!-- pagebreak -->
## Misiunea 3 Depășirea surpriză

**Provocare dificilă pentru toți:** „Amândoi pleacă din coloana 4 și ajung în 16. Câinele merge mereu cu viteza medie. Iepurele începe lent, rămâne în urmă, apoi accelerează și ajunge primul. Cum împarți cei 12 pași?”

Readucem câinele la (4, 4), cu steag, viteză medie, dreapta 12. Iepurele rămâne la (4, 10). La iepure folosim exact două deplasări spre dreapta, cu distanțe pozitive care însumează 12: întâi lent, apoi repede. Copilul alege cele două numere. Fără așteptare, Repeat, mutare sau resetare în timpul cursei.

**Reușită observabilă:** la început câinele este înainte; iepurele îl ajunge și îl depășește pe parcurs; iepurele ajunge primul în coloana 16. Nu este suficient să câștige pornind repede sau să scurteze drumul. Verificăm cursa de două ori, resetând înainte de fiecare probă.

**Soluție pentru profesor:** iepure steag, lent, dreapta 2, repede, dreapta 10. Câine steag, mediu, dreapta 12. Există și alte împărțiri; acceptăm orice program care respectă regulile și rezultatul observat. Nu cerem memorarea perechii 2 și 10.

**Indicii progresive:** mai întâi „Câte spații ai în total?”; apoi „Dacă mergi lent aproape tot drumul, mai ai loc să recuperezi?”; în final „Încearcă o primă bucată lentă scurtă și lasă restul pentru repede”. Folosește 12 jetoane sau numără spațiile grilei dacă adunarea este dificilă. Nu cere împărțiri, fracții sau formule de viteză.

Toți primesc cerința. La nevoie copilul alege între două propuneri de împărțire și construiește una. Colegul explică, dar autorul lucrează pe propria tabletă. Nu transformăm activitatea într-un clasament al copiilor.

## Rezervă 1 Sosim împreună

**6-8 minute, suplimentar.** Folosim starturile din misiunea 2: iepure (4, 10), câine (10, 4), sosire coloana 16. Acum ținta este sosirea împreună, cu viteze diferite și constante. Un singur bloc Viteză și o singură săgeată per personaj. Fără așteptare sau ocoluri.

Copilul decide cine trebuie să meargă mai repede. **Soluție:** iepure repede, dreapta 12; câine mediu, dreapta 6. În aplicație trebuie să pară că se opresc aproape simultan; nu folosim un cronometru și nu cerem precizie la milisecundă. Dacă poziționarea cu degetul diferă, folosim aceeași coloană ca țintă și reglăm starturile înainte de probă.

**Indiciu:** „Cine are drumul de două ori mai lung?”. **Explicație urmărită:** personajul mai îndepărtat trebuie să meargă mai repede pentru a compensa distanța. Profesorul verifică două rulări.

<!-- pagebreak -->
## Rezervă 2 Virajul expres

**8-10 minute, suplimentar.** Copilul construiește un traseu cu două colțuri, folosind exact trei săgeți și toate cele trei viteze, fiecare o dată. Iepurele pornește la **(4, 5)**, trece prin **(8, 5)**, apoi **(8, 9)** și se oprește la **(12, 9)**. Pe grilă numerele verticale cresc de jos în sus. Profesorul arată cele patru puncte pe cartonaș.

Reguli de ritm: prima parte lentă, urcarea rapidă, ultima parte medie. Câinele rămâne la (16, 4), fără program: deconectăm acțiunile lui de la steag sau eliminăm programul înainte de această rezervă. Nu trebuie importat sau desenat un traseu pe tabletă.

**Soluție:** steag, lent, dreapta 4, repede, sus 4, mediu, dreapta 4. **Reușită:** cele două colțuri sunt respectate în ordine, schimbările de ritm sunt vizibile, destinația este (12, 9), iar câinele nu se mișcă. **Indicii:** „Unde este primul colț?”, „Care segment urcă?”, „Câte spații are fiecare bucată?”.

Nu punem toate săgețile după ultimul bloc Viteză: viteza trebuie așezată înaintea segmentului pe care îl controlează. La fiecare schimbare de probă, resetăm numai înaintea pornirii.

## Dificultăți și sprijin

| Ce observăm | Cum ajutăm |
| --- | --- |
| Viteza nu schimbă rezultatul | Blocul Viteză trebuie conectat înaintea deplasării, în programul personajului selectat. |
| Copilul schimbă 12 în 6 ca să câștige | Arătăm din nou ținta și numărăm drumul. Ajustăm viteza, păstrând distanța cerută. |
| Viteza rămâne de la o probă anterioară | Fiecare program alege explicit viteza la început. |
| Pare că se suprapun | Păstrăm cele două rânduri separate și dimensiunea standard. |
| Se compară nasul cu coada | Comparăm centrul personajului cu coloana grilei. |
| Numerele celor două bucăți sunt dificile | Folosim 12 jetoane sau numărăm spațiile grilei. |
| Termină devreme | Oferim R1, apoi R2. Rezervele nu înlocuiesc provocarea dificilă. |

## Încheiere și verificare

Copilul arată un bloc care schimbă viteza și o săgeată care schimbă distanța. Explică o predicție și rezultatul observat. Revine la galerie, redeschide și rulează din nou. Păstrăm repartizarea tabletelor. Fișa pilotului urmărește sprijinul necesar și ce rezerve au fost folosite, fără clasamente.

Exemplele SJR sunt numai pentru profesor; raportul din verificare/README.md precizează probele efectuate. Browserul comunitar nu înlocuiește proba tactilă și offline în aplicația oficială pe Lenovo.

## Referințe

- [Blocurile oficiale ScratchJr](https://www.scratchjr.org/pdfs/blocks.pdf): Set Speed, săgețile și steagul verde.
- [Ghidul interfeței](https://sites.bc.edu/scratchjr/learn/): grila, selectarea personajului și salvarea.
