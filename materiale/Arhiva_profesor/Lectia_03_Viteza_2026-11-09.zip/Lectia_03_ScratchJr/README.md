# Lecția 3 - Curse cu surprize

**50 de minute, 6-7 ani. Trei misiuni principale, una dificilă, plus două puzzle-uri de rezervă.** Mecanismul nou este Set Speed / Viteză: predicția sosirii și schimbarea ritmului în același program.

## Pe tabletele copiilor

Dacă ScratchJr este instalat, nu mai instalăm sau copiem nimic. Proiect nou, câinele **Dog**, iepurele **Rabbit** și fundalul **Park** din bibliotecă. Copiii construiesc programele; SJR-urile sunt numai exemple opționale pentru profesor. Nu folosim conturi, importuri, imagini externe sau descărcări în timpul lecției.

Lecția 1 a lucrat întâlnirea și revenirea, iar lecția 2 Repeat. Lecția 3 aduce curse cu ținte de ordine și timp, un avans și o depășire. Nu sunt necesare sărituri sau bucle.

## Materiale

- [Ghidul profesorului](Ghid_profesor.md) și [PDF-ul](Ghid_profesor_Lectia_03.pdf): pregătire, 50 de minute, indicii și rezerve.
- [Cinci cartonașe PDF](Cartonase_Lectia_03.pdf): trei misiuni și două rezerve, fără programele soluțiilor.
- [Soluții explicate și proiecte](solutii/lectia_03/README.md).
- [Fișa de observații](Observatii_dupa_lectie.md).
- [Raportul testării](verificare/README.md).

## Misiunile

| Activitate | Țintă | Regula principală |
| --- | --- | --- |
| 1. Câinele ajunge primul | Același drum de 12 pași; câinele sosește înaintea iepurelui | O viteză diferită per personaj; distanțe egale |
| 2. Drumul lung poate câștiga? | Iepurele cu 12 pași învinge câinele ce are doar 6 | Schimbăm vitezele, păstrăm starturile și distanțele |
| 3. Depășirea surpriză - dificilă | Câinele conduce la început, iepurele la final | Iepure lent apoi repede; două bucăți cu total 12; câinele mediu |
| R1. Sosim împreună - 6-8 min | 12 și 6 pași, sosire aproape simultană | Viteze diferite și constante; fără așteptare |
| R2. Virajul expres - 8-10 min | Două colțuri și o destinație exactă | Trei săgeți, trei viteze: lent, repede, mediu |

**Rezervele sunt în plus față de cele 50 de minute**, nu obligații înghesuite în orar. Folosește-le individual pentru cei care termină sau cu toată clasa dacă s-a câștigat timp. Păstrează ultimele cinci minute pentru explicație și salvare. Provocarea dificilă este prezentată tuturor, cu indicii; copiii construiesc, fără programe greșite impuse.

## Grila și blocul nou

M1 și M3: iepure (4, 10), câine (4, 4), sosire coloana 16. M2 și R1: câinele începe la (10, 4). Pe grila afișată, primul număr este jos, al doilea în stânga. Comparăm centrele personajelor.

Categoria portocalie conține blocul Viteză. Atinge selectorul mic de pe bloc și alege lent, mediu sau repede. Pune o viteză explicită înaintea primei săgeți. Numărul săgeții rămâne distanța. Resetează înaintea probei și pornește ambele personaje cu steagul verde din bara de sus.

## Testare simplă pe PC

Deschide [ScratchJr Desktop Reborn în browser](https://richiesamlie.github.io/ScratchJr-Desktop-Reborn/play/), un port comunitar. În galerie apasă Open / Import și alege un exemplu SJR, apoi deschide-l și rulează. Revino la galerie pentru salvare și redeschide. Exemple: [demonstrația vitezei](proiecte/00_Demo_Viteza.sjr), [scena fără programe](proiecte/01_Start.sjr), apoi [cele cinci soluții](solutii/lectia_03/README.md).

Nu există sincronizare automată cu tabletele. Pentru copii este suficientă aplicația oficială ScratchJr deja instalată; nu au nevoie de browser sau de proiectele profesorului. Pentru detaliile probelor efectuate și limite vezi [raportul](verificare/README.md).

## Ce a fost testat

Toate cele șapte exemple finale au trecut importul, rularea, ținta, resetarea, salvarea, redeschiderea și a doua rulare în browserul comunitar. Au rămas în galerie după reîncărcare. Am verificat separat selectorul de viteză, depășirea înainte de sosire, cele trei ritmuri ale traseului și sosirea împreună din R1. Detaliile și capturile sunt în [raport](verificare/README.md).

**Lecția 3 nu a fost testată în aplicația oficială Android sau pe Lenovo fizic.**

## Proba pe Lenovo

Pe o tabletă: adaugă iepurele, alege Viteză prin atingere, conectează lent - dreapta 2 - repede - dreapta 10 după steag, apoi programează câinele mediu - dreapta 12. Verifică depășirea, resetarea, salvarea și redeschiderea fără internet. Testele din browser nu certifică gesturile tactile sau performanța K10.

## Surse editabile

`lesson.json` definește programele, țintele și cartonașele. `Ghid_profesor.md` este sursa ghidului. `python build_pack.py` generează PDF-urile și cele șapte SJR-uri; `--projects-only` generează numai proiectele. Necesită Python, reportlab, Pillow, pypdf și fonturile Arial din Windows. Fișierele SJR sunt deterministe; după modificarea programelor, repetă testele și actualizează raportul.

[Planul celor zece lecții](../Plan_10_lectii_ScratchJr.md). `index.html` este indexul materialelor profesorului.
