# Observații după lecția 3

Data: __________ Grupa: __________ Număr de copii: __________

| Tableta | Alege viteza | Separă viteza de distanță | Construiește depășirea | Explică predicția | Rezervă încercată |
| --- | --- | --- | --- | --- | --- |
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |
| 11 | | | | | |
| 12 | | | | | |

S = singur, I = cu indiciu, E = mai exersăm. Adaugă rânduri dacă este nevoie. Rezerve: R1, R2 sau niciuna; nu sunt criteriu de clasificare a copiilor.

## După pilot

- Câte minute a durat scena și selectorul de viteză? __________
- Au păstrat distanțele când au schimbat vitezele? __________
- Cine a explicat de ce iepurele recuperează? __________
- Au fost utile jetoanele pentru împărțirea celor 12 pași? __________
- Cât timp a rămas? Ce rezerve au fost folosite? __________
- Ce a fost prea ușor sau prea greu? __________

## Proba pe K10

- [ ] Dog, Rabbit și Park sunt disponibile, fără resurse copiate.
- [ ] Selectorul lent / mediu / repede funcționează cu degetul.
- [ ] Viteza schimbă ritmul și păstrează distanța.
- [ ] Câinele conduce la început, apoi iepurele îl depășește în M3.
- [ ] R1 arată o sosire aproape simultană.
- [ ] R2 respectă colțurile și schimbările de viteză.
- [ ] Resetarea, salvarea și redeschiderea fără internet funcționează.
