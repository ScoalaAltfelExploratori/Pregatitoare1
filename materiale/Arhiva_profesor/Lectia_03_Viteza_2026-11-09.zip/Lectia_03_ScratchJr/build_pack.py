"""Regenerate Lesson 3 PDFs and ScratchJr examples from editable sources.
Requires Python 3, reportlab, Pillow and pypdf.
"""
from pathlib import Path
import json, re, hashlib, zipfile, io, html
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from PIL import Image, ImageDraw
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/"lesson.json").read_text(encoding="utf-8-sig"))
FONT_DIR=Path("C:/Windows/Fonts")
pdfmetrics.registerFont(TTFont("Body",str(FONT_DIR/"arial.ttf")))
pdfmetrics.registerFont(TTFont("Bold",str(FONT_DIR/"arialbd.ttf")))
pdfmetrics.registerFontFamily("Body",normal="Body",bold="Bold",italic="Body",boldItalic="Bold")
INK=colors.HexColor("#173e3a"); TEAL=colors.HexColor("#087f75"); MUTED=colors.HexColor("#58716b")
BLUE=colors.HexColor("#66b5ed"); YELLOW=colors.HexColor("#ffd35d")
PAPER=colors.HexColor("#fffdf8"); LINE=colors.HexColor("#dce6df"); MINT=colors.HexColor("#def2e9")
W,H=landscape(A4)

def rabbit(c,x,y,r=25):
    # Schematic rabbit for printable cards; the app uses bundled Rabbit.svg.
    c.setFillColor(colors.HexColor("#b9783e"));c.setStrokeColor(colors.HexColor("#674126"));c.setLineWidth(1.4)
    c.ellipse(x-r*.6,y-r*.65,x+r*.65,y+r*.5,fill=1,stroke=1)
    c.ellipse(x-r*.55,y+r*.25,x-r*.16,y+r*1.4,fill=1,stroke=1)
    c.ellipse(x-r*.04,y+r*.25,x+r*.35,y+r*1.4,fill=1,stroke=1)
    c.circle(x,y+r*.25,r*.57,fill=1,stroke=1)
    c.setFillColor(INK);c.circle(x-r*.18,y+r*.37,r*.055,fill=1,stroke=0);c.circle(x+r*.18,y+r*.37,r*.055,fill=1,stroke=0)
    c.setFillColor(colors.HexColor("#e9a8a1"));c.circle(x,y+r*.14,r*.07,fill=1,stroke=0)

def paragraph(c,text,x,y,width,font="Body",size=15,leading=None,color=INK):
    st=ParagraphStyle("local",fontName=font,fontSize=size,leading=leading or size*1.4,textColor=color)
    p=Paragraph(text,st);pw,ph=p.wrap(width,1000);p.drawOn(c,x,y-ph);return y-ph

def page_header(c,label,title,sub=""):
    c.setFillColor(PAPER);c.rect(0,0,W,H,fill=1,stroke=0);c.setFillColor(TEAL)
    c.setFont("Bold",10);c.drawString(42,H-38,"SCRATCHJR / LECȚIA 3");c.drawRightString(W-42,H-38,label.upper())
    c.setFillColor(INK);c.setFont("Bold",30);c.drawString(42,H-89,title)
    if sub:paragraph(c,sub,42,H-107,W-84,size=16,color=MUTED)
    c.setStrokeColor(LINE);c.line(42,38,W-42,38);c.setFillColor(MUTED);c.setFont("Body",9)
    c.drawString(42,23,"Blocuri și trasee desenate schematic. Lucrăm în aplicația ScratchJr.");c.drawRightString(W-42,23,str(c.getPageNumber()))

def fmt(s):
    s=html.escape(s);s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<link href="\2" color="#087f75">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s);s=re.sub(r'\x60([^\x60]+)\x60',r'<b>\1</b>',s)
    return s.replace("–","-").replace("—","-")

def teacher_pdf():
    out=ROOT/"Ghid_profesor_Lectia_03.pdf"
    st={
      "body":ParagraphStyle("body",fontName="Body",fontSize=10.5,leading=14.5,textColor=INK,spaceAfter=7),
      "h1":ParagraphStyle("h1",fontName="Bold",fontSize=25,leading=30,textColor=INK,spaceAfter=15,keepWithNext=True),
      "h2":ParagraphStyle("h2",fontName="Bold",fontSize=16,leading=20,textColor=INK,spaceBefore=14,spaceAfter=8,keepWithNext=True),
      "cell":ParagraphStyle("cell",fontName="Body",fontSize=9.2,leading=12.5,textColor=INK),
      "list":ParagraphStyle("list",fontName="Body",fontSize=10.5,leading=14.5,textColor=INK,leftIndent=10,spaceAfter=6)}
    lines=(ROOT/"Ghid_profesor.md").read_text(encoding="utf-8-sig").splitlines();story=[];i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line == "<!-- pagebreak -->":
            story.append(PageBreak());i+=1;continue
        if line.startswith("|"):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith("|"):
                cells=[x.strip() for x in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"[-: ]+",x) for x in cells):rows.append(cells)
                i+=1
            n=len(rows[0]);widths=[135,380] if n==2 else [53,103,359]
            t=Table([[Paragraph(fmt(v),st["cell"]) for v in r] for r in rows],colWidths=widths,repeatRows=1,hAlign="LEFT")
            t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),MINT),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),8),("RIGHTPADDING",(0,0),(-1,-1),8),("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7),("LINEBELOW",(0,0),(-1,-1),.4,LINE)]))
            story.extend([t,Spacer(1,10)]);continue
        if line.startswith("# "):story.append(Paragraph(fmt(line[2:]),st["h1"]))
        elif line.startswith("## "):
            story.append(Paragraph(fmt(line[3:]),st["h2"]))
        elif line.startswith("- "):story.append(Paragraph("• "+fmt(line[2:]),st["list"]))
        elif re.match(r"^\d+\. ",line):story.append(Paragraph(fmt(line),st["list"]))
        else:story.append(Paragraph(fmt(line),st["body"]))
        i+=1
    def decorate(c,doc):
        pw,ph=A4;c.saveState();c.setFont("Body",8);c.setFillColor(MUTED)
        c.drawString(40,ph-26,"SCRATCHJR / LECȚIA 3 / GHID PENTRU PROFESOR")
        c.setStrokeColor(LINE);c.line(40,36,pw-40,36)
        c.drawString(40,23,"50 de minute · 6-7 ani · Versiune pentru probă");c.drawRightString(pw-40,23,str(doc.page));c.restoreState()
    SimpleDocTemplate(str(out),pagesize=A4,leftMargin=40,rightMargin=40,topMargin=48,bottomMargin=49,title="Lecția 3 ScratchJr - Ghidul profesorului").build(story,onFirstPage=decorate,onLaterPages=decorate)
    reader=PdfReader(str(out));extracted="\n".join(p.extract_text() for p in reader.pages)
    for phrase in ["Misiunea 1","Misiunea 2","Dificultăți și sprijin","50 de minute"]:assert phrase in extracted,phrase
    return len(reader.pages)



def dog(c,x,y,r=22):
    c.setFillColor(colors.HexColor('#fffaf0'));c.setStrokeColor(INK);c.setLineWidth(1.2)
    c.ellipse(x-r*.8,y-r*.7,x+r*.8,y+r*.9,fill=1,stroke=1)
    c.setFillColor(colors.HexColor('#965a2e'))
    for dx in [-1,1]:c.ellipse(x+dx*r*.75-r*.35,y-r*.35,x+dx*r*.75+r*.35,y+r*.95,fill=1,stroke=1)
    c.setFillColor(INK)
    for dx in [-.3,.3]:c.circle(x+r*dx,y+r*.35,r*.07,fill=1,stroke=0)
    c.circle(x,y-r*.05,r*.12,fill=1,stroke=0)

def race_diagram(c,m):
    x,y,w,h=42,225,355,188
    c.setFillColor(MINT);c.roundRect(x,y,w,h,15,fill=1,stroke=0)
    left=x+40;step=22;finish=left+12*step
    c.setFont('Bold',12);c.setFillColor(INK);c.drawCentredString(x+w/2,y+h-25,'Sosire: coloana 16')
    c.setStrokeColor(TEAL);c.setDash(3,3);c.line(finish,y+28,finish,y+133);c.setDash()
    for i,(start,draw) in enumerate(zip(m['starts'],[rabbit,dog])):
        yy=y+112-i*65;sx=left+(start-4)*step
        c.setStrokeColor(colors.HexColor('#94bdb3'));c.setLineWidth(2);c.line(sx,yy,finish,yy)
        draw(c,sx,yy+4,19)
        c.setFillColor(INK);c.setFont('Bold',11);c.drawCentredString((sx+finish)/2,yy+14,str(16-start)+' pași')
        c.setFont('Body',10);c.drawCentredString(sx,yy-24,'col. '+str(start))
    c.setFont('Body',11);c.setFillColor(MUTED)
    paragraph(c,'Două trasee paralele. Comparăm centrele personajelor cu aceeași coloană.',47,201,345,size=15,color=MUTED)

def corner_diagram(c):
    c.setFillColor(MINT);c.roundRect(42,225,355,188,15,fill=1,stroke=0)
    pts=[(80,265),(208,265),(208,365),(336,365)]
    c.setStrokeColor(TEAL);c.setLineWidth(3)
    for a,b in zip(pts,pts[1:]):c.line(*a,*b)
    for pt,label in zip(pts,['(4, 5)','(8, 5)','(8, 9)','(12, 9)']):
        c.setFillColor(TEAL);c.circle(*pt,5,fill=1,stroke=0)
        c.setFillColor(INK);c.setFont('Bold',11);c.drawCentredString(pt[0],pt[1]-24,label)
    rabbit(c,80,291,16)
    c.setFillColor(INK);c.setFont('Body',11);c.drawCentredString(140,277,'lent');c.drawString(219,315,'repede');c.drawCentredString(273,377,'mediu')
    paragraph(c,'Primul număr: coloana. Al doilea: rândul. Numără spațiile până la fiecare colț.',47,201,345,size=15,color=MUTED)

def cards():
    out=ROOT/'Cartonase_Lectia_03.pdf';c=canvas.Canvas(str(out),pagesize=(W,H))
    c.setTitle('Lecția 3 - Trei misiuni și două rezerve')
    for m in D['missions']:
        page_header(c,m['label'],m['title'],m['subtitle'])
        if m.get('route'):corner_diagram(c)
        else:race_diagram(c,m)
        y=410
        for n,t in enumerate(m['steps'],1):
            c.setFillColor(TEAL);c.circle(440,y-11,12,fill=1,stroke=0)
            c.setFillColor(colors.white);c.setFont('Bold',12);c.drawCentredString(440,y-15,str(n))
            y=paragraph(c,t,464,y,325,size=16)-21
        assert y>125,(m['title'],y)
        c.setFillColor(MINT);c.roundRect(42,65,W-84,57,13,fill=1,stroke=0)
        paragraph(c,m['success'],59,104,W-118,font='Bold',size=13.5)
        c.showPage()
    c.save();assert len(PdfReader(str(out)).pages)==5

def thumbnail():
    from PIL import ImageFont
    im=Image.new('RGB',(160,120),'#e9f6f5');d=ImageDraw.Draw(im)
    d.rounded_rectangle((7,7,153,113),radius=14,fill='#d0e8bb')
    d.text((80,28),'L03',font=ImageFont.truetype(str(FONT_DIR/'arialbd.ttf'),32),fill='#173e3a',anchor='mt')
    d.text((80,74),'Viteza',font=ImageFont.truetype(str(FONT_DIR/'arial.ttf'),17),fill='#173e3a',anchor='mt')
    stream=io.BytesIO();im.save(stream,format='PNG');return stream.getvalue()

def projects():
    png=thumbnail();thumb=hashlib.md5(png).hexdigest()+'.png'
    for e in D['projects']:
        page={'textstartat':36,'sprites':['iepuras1','caine1'],'md5':'Park.svg','num':1,
              'lastSprite':'iepuras1','layers':['iepuras1','caine1']}
        for key,name,entry,w,h in [('iepuras1','Rabbit',e['rabbit'],217,208),('caine1','Dog',e['dog'],296,213)]:
            x,y=entry['start'];cmds=entry['program']
            blocks=[['onflag','null',40,60]]+[[v['block'],v['value'],113+65*i,60] for i,v in enumerate(cmds)] if cmds else []
            page[key]={'shown':True,'type':'sprite','md5':name+'.svg','id':key,'flip':False,'name':name,
                'angle':0,'scale':.5,'speed':2,'defaultScale':.5,'sounds':['pop.mp3'],
                'xcoor':x,'ycoor':y,'cx':w/2,'cy':h/2,'w':w,'h':h,'homex':x,'homey':y,
                'homescale':.5,'homeshown':True,'homeflip':False,'scripts':[blocks] if blocks else []}
            if cmds:assert cmds[0]['block']=='setspeed'
            for c in cmds:
                assert c['block'] in ['setspeed','forward','up']
                if c['block']=='setspeed':assert c['value'] in [0,1,2]
                elif c['block']=='forward':x+=24*c['value']
                elif c['block']=='up':y-=24*c['value']
                assert 54<=x<=426 and 60<=y<=300
            assert [x,y]==e['expected']['rabbit_end' if key=='iepuras1' else 'dog_end']
        bag={'name':e['name'],'version':'iOSv01','mtime':'1794225600000','ctime':'2026-11-09 12:00:00',
             'deleted':'NO','isgift':'1','thumbnail':{'pagecount':1,'md5':thumb},
             'json':{'pages':['page1'],'currentPage':'page1','page1':page}}
        target=ROOT/e['path'];target.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in [('project/data.json',json.dumps(bag,ensure_ascii=False,separators=(',',':')).encode()),('project/thumbnails/'+thumb,png)]:
                info=zipfile.ZipInfo(name,(2026,11,9,12,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
        with zipfile.ZipFile(target) as z:
            assert z.testzip() is None and len(z.namelist())==2
            assert json.loads(z.read('project/data.json'))['json']['page1']==page
        print(e['path'],e['expected'])

if __name__=='__main__':
    import sys
    if '--projects-only' not in sys.argv:
        cards();print('Teacher pages:',teacher_pdf())
    projects()
