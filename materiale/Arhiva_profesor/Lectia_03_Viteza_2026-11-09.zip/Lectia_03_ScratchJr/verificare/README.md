# Verificarea lecției 3 - 9 noiembrie 2026

Setul final folosește **Rabbit + Dog + Park**, numai resurse incluse în aplicație. Copiii construiesc scenele și programele; fișierele SJR sunt exemple opționale pentru profesor.

## Mediul și metoda

Testele au fost efectuate în [ScratchJr Desktop Reborn](https://richiesamlie.github.io/ScratchJr-Desktop-Reborn/play/), un port comunitar, într-un browser separat, în fundal. Nu este aplicația oficială Android.

Fiecare dintre cele șapte fișiere a fost importat prin selectorul din galerie, deschis și pornit prin steagul verde de sus. Am înregistrat pozițiile personajelor din stilurile DOM afișate pe scenă, fără apelarea motorului intern. Am verificat rezultatul, resetarea, salvarea prin galerie, redeschiderea și o a doua rulare. Toate șapte au rămas în galerie după reîncărcarea browserului.

Timpii din observații includ costul automatizării și nu sunt durate de cerut copiilor. Contează ordinea sosirii, țintele și forma mișcării. Coordonatele CSS ale imaginilor diferă de centrele scenei; centrele au fost reconstruite din starturile proiectului și deplasările efectiv afișate.

## Rezultate

| Exemplu | Criteriul verificat în ambele rulări | Rezultat |
| --- | --- | --- |
| Demo | Iepurele parcurge două segmente de 3 pași; al doilea este vizibil mai rapid; câinele stă | PASS |
| Start | Ambele programe goale; personajele rămân pe loc | PASS |
| M1 | 12 pași fiecare; câinele ajunge primul; ambele centre ajung la x=360 | PASS |
| M2 | Iepurele parcurge 12 pași și câștigă; câinele parcurge 6 | PASS |
| M3 dificilă | Câinele conduce la început; iepurele îl depășește înainte de sosire și câștigă | PASS |
| R1 | Drumuri de 12 și 6 pași, viteze diferite; sosire împreună în aceeași probă de poziție | PASS |
| R2 | Colțurile (8, 5), (8, 9), final (12, 9); câinele rămâne nemișcat; ritm lent, rapid, mediu | PASS |

R1 a ajuns la destinație în același eșantion pentru ambele personaje în cele două rulări. Verificarea automată admite 120 ms diferență de eșantionare; criteriul clasei este sosirea vizual aproape simultană, fără cronometru.

Pentru demonstrație și R2 am comparat deplasările pe intervale consecutive din observațiile animației, excluzând opririle dintre blocuri. Ordinea vitezelor a fost confirmată în ambele rulări. Acesta este un calcul pe observații reale, nu o simulare a blocurilor.

## Selectorul de viteză și grila

Am deschis selectorul de pe primul bloc Viteză al iepurelui, am ales mediu, apoi am revenit la lent. Am rulat M3, am salvat, am redeschis și am rulat din nou; depășirea a rămas corectă. Aceasta verifică alegerea vitezei prin interfață și persistența ei. Nu am reconstruit toate cele șapte programe bloc cu bloc prin tragere în această sesiune.

Grila afișată a confirmat iepurele la (4, 10) și câinele la (4, 4). Cei 12 pași duc din coloana 4 în coloana 16; șase pași duc din 10 în 16. Poziționarea tactilă se verifică pe tabletă.

## Dovezi

- [Observații complete](browser_observatii.json): cele două rulări, destinații, ordinea sosirii și resetare pentru toate cele șapte fișiere.
- [Selector și redeschidere](browser_selector.json): proba de alegere a vitezei, grila și două rulări M3.
- [Viteze observate](browser_viteze.json): comparația segmentelor din demo și R2.
- [Amprentele SHA-256](rezultate.json): identifică exact fișierele verificate.
- Capturi: [demo](00_Demo_Viteza.png), [start](01_Start.png), [M1](01_Cainele_primul.png), [M2](02_Drum_lung_castigator.png), [M3](03_Depasirea.png), [depășire în curs](03_Depasirea_in_cursa.png), [R1](04_Rezerva_Sosire_impreuna.png), [R2](05_Rezerva_Virajul_expres.png).

Arhivele au fost verificate structural: JSON valid, două personaje, dimensiuni native și referințe la Rabbit.svg, Dog.svg, Park.svg, cu programele și țintele din lesson.json. Nu conțin imagini personalizate de distribuit copiilor. Resursele și dimensiunile au fost confirmate în media.json al aplicației oficiale Android 1.5.11 instalate anterior din Google Play.

## Problemă găsită și rezolvată

Un prototip inițial folosea Cat.svg. Portul comunitar a afișat o eroare de încărcare pentru acea resursă. Setul distribuit folosește Dog.svg și a fost verificat integral după schimbare. Documentele, cartonașele și soluțiile folosesc toate câinele; prototipul cu pisică nu este inclus în pachet.

## Limite

Lecția 3 **nu a fost testată în aplicația oficială Android sau pe un Lenovo K10 fizic**. Rămân proba selectorului cu degetul, poziționarea, fluiditatea, salvarea și redeschiderea fără internet. Urmează [proba din README](../README.md). Importul proiectelor pe tabletele copiilor nu este necesar.

Ghidul de patru pagini și cele cinci cartonașe au fost randate și inspectate vizual, pagină cu pagină. Diagramele sunt scheme, nu capturi ale editorului. Rezervele sunt explicit separate de planul de 50 de minute.

Indexul materialelor a fost verificat și în browser, inclusiv deschiderea exemplului din secțiunea profesorului. [Captura indexului](index_materiale.png).
