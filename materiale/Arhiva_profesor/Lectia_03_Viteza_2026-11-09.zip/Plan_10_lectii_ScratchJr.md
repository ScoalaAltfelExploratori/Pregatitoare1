# Planul celor 10 lecții ScratchJr pentru copii de 6 și 7 ani

Plan de lucru pentru 10 întâlniri de câte 50 de minute, cu o tabletă Lenovo K10 de 3 GB RAM pentru fiecare copil. Copiii au parcurs deja exercițiile Robo Explorator. Cursul începe direct în ScratchJr și folosește această experiență pentru a trece de la rezolvarea unor trasee la crearea de animații, scene interactive și povești.

Materialele și explicațiile pentru copii vor fi în română, cu pictograme și demonstrații scurte. Planul este o primă versiune, din 9 noiembrie 2026; ritmul se ajustează după primele două întâlniri.

## Regula cursului: totul se construiește în aplicație

Toate cele zece lecții folosesc numai personajele, fundalurile, sunetul Pop și blocurile incluse în ScratchJr. Nu cerem importuri SJR, imagini externe, conturi ale copiilor, descărcări de materiale sau copierea fișierelor pe fiecare tabletă. Instalăm aplicația o singură dată; lecțiile se pot desfășura fără internet după verificarea inițială pe K10.

Profesorul arată un pas, copiii îl fac în propriul proiect, apoi continuăm. Scenele de început se construiesc împreună în timpul lecției. Proiectele pregătite sunt referințe opționale pentru profesor.

**Decizie de proiectare, 9 noiembrie 2026:** pentru toate lecțiile folosim misiuni de construire, cu ținte concrete. Copiii nu construiesc intenționat programe greșite pentru a le repara. Depanarea apare firesc atunci când propriul proiect nu face încă ce au intenționat. Profesorul ajută prin întrebări și indicii, fără o etapă separată de copiere a unei greșeli.

**În fiecare lecție includem un exercițiu dificil.** Acesta combină mecanisme deja explicate și are un rezultat verificabil, nu înseamnă doar mai multă decorare sau copiere. Îl prezentăm tuturor, cu indicii progresive; terminarea lui fără ajutor nu este o condiție de reușită a lecției. Conținutul exact se rafinează la pregătirea fiecărei întâlniri.

**Din lecția 3 pregătim și două puzzle-uri de rezervă**, peste conținutul de bază pentru 50 de minute. Le folosim pentru cei care termină repede sau dacă întreaga clasă câștigă timp. Rezervele au cerințe, indicii și soluții; nu înlocuiesc exercițiul dificil prezentat tuturor sau timpul final de salvare.

Păstrăm aceeași tabletă pentru fiecare copil. Lecția 2 poate refolosi scena lecției 1; pentru lecția 3 recomandăm un proiect nou cu iepure și câine. Lecția 10 continuă proiectul din lecția 9. Salvarea în galerie și redeschiderea încheie fiecare întâlnire.

| Lecția | Resurse din aplicație | Pornire fără distribuirea fișierelor |
| --- | --- | --- |
| 1 | Rabbit, Ball, Park; sunt acceptate și alte două personaje | Proiect nou, două personaje, un fundal |
| 2 | Rabbit, Ball și Park; mingea rămâne un reper fix | Refolosim scena sau creăm una nouă; programele sunt construite de copii |
| 3 | Rabbit, Dog și Park | Proiect nou, două trasee paralele și selectorul Viteză |
| 4 | Două sau trei personaje din bibliotecă | Proiect nou, reacții la atingere |
| 5 | Personaje la alegere și sunetul Pop inclus | Fără fișiere audio sau înregistrări obligatorii |
| 6 | Două personaje și sărituri ori Pop | Secvențe pe rând, fără replici de scris |
| 7 | Două personaje și mesaje colorate | Un singur mesaj în același proiect |
| 8 | Două fundaluri din bibliotecă, de exemplu Park și Beach Day | Adăugăm a doua pagină în aplicație |
| 9 | Orice resurse deja disponibile în aplicație | Construim proiectul personal pe tableta copilului |
| 10 | Proiectul salvat la lecția 9 | Redeschidem pe aceeași tabletă |

Nu presupunem existența unui magazin de resurse în aplicație. Biblioteca instalată este suficientă. Desenul sau înregistrarea făcute direct în editor pot fi extensii alese de copil, fără descărcări, dar nu sunt necesare pentru exercițiile de bază.

## Ce urmărim

La final, copilul poate să construiască și să modifice un program scurt, să prevadă ce va face, să-l testeze și să repare o nepotrivire. Poate să folosească un eveniment de pornire, să recunoască o secvență repetată și să explice cu propriile cuvinte o parte din proiectul său.

Fiecare lecție are o idee principală, două exerciții de bază și un exercițiu dificil inclus în materialele și timpul lecției. Reușita înseamnă un comportament observabil și o explicație simplă, fără note, clasamente sau viteză impusă. Copiii pot crea proiecte diferite care îndeplinesc aceeași cerință.

Citirea fluentă și scrierea de replici nu sunt condiții de participare. Profesorul demonstrează, citește cerințele și folosește exemple vizuale. Copiii pot explica oral sau prin gesturi.

## Ritmul unei întâlniri

Acest program este orientativ pentru lecțiile 4–8. Lecțiile 1, 2, 3, 9 și 10 au organizare proprie, tot de 50 de minute. La pregătirea fiecărei lecții rezervăm timp și pentru exercițiul dificil.

| Interval | Activitate |
| --- | --- |
| 0–5 min | Recapitulare sau joc fără tabletă |
| 5–10 min | Demonstrarea unei idei și anticiparea rezultatului |
| 10–22 min | Exercițiul 1 cu sprijin |
| 22–25 min | Pauză de mișcare cu tabletele puse jos |
| 25–40 min | Exercițiul 2 și provocarea pentru cei pregătiți |
| 40–45 min | O variație personală a proiectului |
| 45–50 min | Două exemple, o întrebare de recapitulare și verificarea salvării |

În timpul demonstrației, copiii privesc exemplul. Apoi lucrează și profesorul circulă. Dacă aceeași dificultate apare la mai mulți copii, se face o demonstrație scurtă pentru toți, în timpul alocat exercițiului.

Întrebările de ajutor sunt: „Ce ai vrut să se întâmple?”, „Ce s-a întâmplat?” și „Ce bloc ai schimba?”. Copilul păstrează controlul tabletei. Un coleg poate explica sau arăta, fără să execute tot programul în locul lui.

## Parcursul celor 10 lecții

| Lecția | Ideea principală | Creația copilului |
| --- | --- | --- |
| 1 | Două personaje cu programe proprii | O întâlnire cu un final inventat |
| 2 | Repetăm un grup de acțiuni | Trei provocări cu trasee și ținte precise |
| 3 | Viteza personajelor | Curse cu avans și depășire, plus două puzzle-uri de rezervă |
| 4 | Pornim prin atingerea personajului | O scenă cu surprize |
| 5 | Programăm sunete | Animale care se aud |
| 6 | Folosim așteptarea | O conversație pe rând |
| 7 | Un mesaj pornește alt personaj | O ștafetă |
| 8 | Legăm două scene | O poveste în două pagini |
| 9 | Planificăm și construim | Prima versiune a unui proiect propriu |
| 10 | Testăm, îmbunătățim și explicăm | Proiectul final și prezentarea lui |

Mesajele din lecția 7 pot rămâne o demonstrație și o extensie dacă grupa are nevoie de consolidare. Proiectul final poate fi realizat cu secvențe, repetiții și pornire prin atingere, fără mesaje sau mai multe pagini.

## Lecția 1 Ne întâlnim la joacă

Materiale pentru probă: [proiectele și fișele](Lectia_01_ScratchJr/index.html), [ghidul profesorului](Lectia_01_ScratchJr/Ghid_profesor.md) și [cartonașele](Lectia_01_ScratchJr/Cartonase_Lectia_01.pdf). Profesorul și copiii lucrează direct în aplicația ScratchJr; pagina este numai un index al fișierelor.

Pachetul lecției 1 include mini-puzzle-ul de revenire și provocarea dificilă. Copiii continuă propriul proiect funcțional.

**Ideea:** folosim experiența Robo într-un proiect creativ cu două personaje și programe separate.

**Împreună:** profesorul rulează o scenă în care două personaje se apropie și sar. Copiii creează apoi scena din biblioteca aplicației; profesorul demonstrează selectarea personajului, conectarea blocurilor, schimbarea unei valori și pornirea la steag.

1. **Construim întâlnirea:** copiii aleg direcții și distanțe pentru ambele personaje și adaugă o săritură.
2. **Două blocuri până acasă:** după întâlnire și săritură, fiecare personaj revine la start; copilul adaugă exact o săgeată per program. **Mai greu, pentru toți:** aceeași revenire cu două săgeți cu numere diferite, pozitive. Fără blocul Acasă, Repeat sau intervenție în timpul rulării.
3. **Inventăm finalul:** fiecare adaugă o acțiune proprie. Mai multe sărituri sau un mic dans înainte de întoarcere sunt exemple posibile.

**Ritm:** 0–5 demonstrație a proiectului; 5–12 construim scena din bibliotecă; 12–22 programăm; 22–25 pauză; 25–35 mini-puzzle și provocare dificilă; 35–45 creație proprie; 45–50 prezentare și salvare.

**Verificare:** copilul selectează personajul corect, ajustează mișcarea, explică direcția și distanța revenirii și inventează un final propriu. Fișierele SJR sunt numai exemple opționale pentru profesor. Copiii nu importă nimic. Numărul blocului de săritură indică înălțimea, nu numărul de sărituri.

## Lecția 2 Provocările iepurașului

**Stare:** pachet pregătit în [Lectia_02_ScratchJr](Lectia_02_ScratchJr/README.md), cu ghid, trei cartonașe, demonstrație și soluții pentru profesor. Cele cinci exemple au trecut testele browserului comunitar; proba pe Lenovo rămâne de făcut. Principii aplicate: ținte concrete, construire de către copii, fără programe greșite impuse și un exercițiu dificil inclus.

**Ideea nouă:** blocul Repeat repetă un grup de acțiuni în aceeași ordine. Diferențiem numărul de repetări de distanța unei deplasări.

**Pregătire:** Rabbit, Ball și Park din biblioteca aplicației. Putem refolosi scena lecției 1, dar construim programele acestei lecții și lăsăm mingea fără program. Mingea este un reper fix pentru destinație; nu folosim detectarea coliziunilor. Profesorul arată poziționarea cu grila. Pentru țintele de deplasare contează coloana destinației; mingea poate sta pe un rând inferior, astfel încât să nu acopere iepurele. Așezarea a fost verificată în browser: iepurele la (5, 7) pe grila afișată, mingea la (11, 3), apoi la (13, 3). Numerele grilei diferă de coordonatele interne ale scenei.

**Împreună:** demonstrăm numai mecanismul: punem două acțiuni cunoscute în Repeat, alegem numărul de repetări și anticipăm rezultatul. Copiii nu primesc programul complet al fiecărei misiuni. Nu cerem calcule de înmulțire; putem număra deplasările pe grilă sau mima grupul de acțiuni.

1. **Misiunea 1 — Trei patrulări:** construiește un program în care iepurele merge la dreapta, sare și revine la start, de trei ori. Folosește un singur Repeat, fără trei copii ale secvenței. Reușită: trei sărituri, trei reveniri și poziția finală egală cu startul. Exemplu pentru profesor: steag → repetă 3 [dreapta 2, sari 2, stânga 2].
2. **Misiunea 2 — Ajungem la țintă:** destinația este la șase pătrățele spre dreapta. Construiește trei deplasări egale, cu o săritură după fiecare, folosind Repeat. Reușită: trei sărituri și oprire pe coloana țintei. Exemplu: steag → repetă 3 [dreapta 2, sari 2].
3. **Misiunea dificilă — Expediția dus-întors:** mută ținta la opt pătrățele spre dreapta. Ajungi acolo în patru deplasări egale, cu o săritură după fiecare, apoi revii la start cu un al doilea Repeat. Totul pornește de la un singur steag; fără resetare între dus și întors. Reușită: atinge coloana țintei după patru sărituri și revine singur la start. Exemplu: steag → repetă 4 [dreapta 2, sari 2] → repetă 4 [stânga 2]. Revenirea poate include și sărituri, dacă elevul le dorește.

Varianta de opt pătrățele în patru deplasări și întoarcerea cu o a doua buclă sunt incluse în exercițiul dificil, construit de copil. Nu modificăm intenționat un program corect ca să producă o greșeală.

**Ritm, 50 de minute:** 0–6 deschidem scena și demonstrăm Repeat; 6–16 misiunea 1; 16–26 misiunea 2; 26–29 pauză de mișcare; 29–44 misiunea dificilă, cu indicii; 44–50 demonstrații și salvare. Dacă pregătirea scenei consumă mai mult timp, scurtăm prima misiune prin sprijin comun, păstrând timp pentru încercarea provocării dificile.

**Indicii pentru exercițiul dificil:** întâi construiește drumul până la țintă; apoi arată direcția de întoarcere; în cele din urmă construiește o a doua buclă. Nu cerem bucle imbricate sau blocuri încă neexplicate.

**Verificare:** copilul arată ce grup se repetă, de câte ori și dacă rezultatul respectă ținta. În cazul unei nepotriviri, îl ajutăm să compare ce a dorit cu ce s-a întâmplat în propriul program. ScratchJr nu acordă automat un calificativ; verificăm prin rulare și discuție.

**Sprijin:** alegerea personajelor și a numerelor poate fi asistată; construcția programului rămâne la copil. Sari 2 înseamnă o singură săritură de înălțime 2. Resetăm înainte de o nouă probă completă, nu în mijlocul expediției dus-întors.

## Lecția 3 Curse cu surprize

**Stare:** pachet pregătit în [Lectia_03_ScratchJr](Lectia_03_ScratchJr/README.md), cu ghid de patru pagini, cinci cartonașe, demonstrație, starter și cinci soluții. Cele șapte exemple au trecut testele browserului comunitar. Proba tactilă și offline pe Lenovo rămâne de făcut.

**Ideea nouă:** Set Speed / Viteză schimbă ritmul acțiunilor următoare ale aceluiași personaj. Păstrăm distanțe și ținte precise, dar anticipăm ordinea sosirii. Lecția este despre avans și depășire, fără sărituri, întoarceri sau Repeat.

**Pregătire:** proiect nou cu Rabbit, Dog și Park din bibliotecă. Iepurele la (4, 10), câinele la (4, 4) pe grila afișată. Sunt pe rânduri separate; sosirea este coloana 16. Fiecare program alege explicit viteza înaintea primei deplasări. Pornim cu un singur steag din bara de sus; resetăm înainte de probă.

1. **Câinele ajunge primul:** amândoi merg 12 pași. Copiii aleg viteze diferite astfel încât câinele să câștige; distanțele rămân egale.
2. **Drumul lung poate câștiga?:** câinele primește avans, până în coloana 10, și are doar 6 pași. Iepurele are 12. Copilul alege vitezele pentru ca iepurele să câștige, fără să schimbe starturile sau distanțele.
3. **Depășirea surpriză - dificilă, pentru toți:** amândoi pornesc din 4 și au 12 pași. Câinele merge mediu. Iepurele începe lent, apoi accelerează și câștigă. Copilul împarte drumul în exact două deplasări pozitive. Exemplu pentru profesor: lent, dreapta 2, repede, dreapta 10. Verificăm că este în urmă la început și depășește înainte de sosire.

**Două rezerve în plus:** R1, „Sosim împreună” (6-8 minute): 12 și 6 pași, viteze constante diferite, sosire aproape simultană. R2, „Virajul expres” (8-10 minute): iepure (4, 5) → (8, 5) → (8, 9) → (12, 9), trei săgeți, lent apoi repede apoi mediu; câinele stă. Au cartonașe, indicii și soluții complete. Nu sunt obligatorii în cele 50 de minute.

**Ritm:** 0-5 predicție și demonstrație; 5-11 scenă și selectorul de viteză; 11-20 M1; 20-29 M2; 29-32 pauză; 32-45 M3; 45-50 explicație, salvare și redeschidere. Rezervele folosesc timpul câștigat, fără eliminarea pauzei sau a încheierii.

**Sprijin și verificare:** comparăm centrele personajelor cu grila și numărăm spațiile, fără precizie la pixel sau cronometru. Pentru împărțirea celor 12 pași folosim jetoane. Copiii explică ce schimbă viteza și ce schimbă numărul săgeții. Construiesc propriile programe; nu copiază greșeli impuse.

## Lecția 4 Personajele răspund la atingere

**Ideea:** un eveniment poate porni un program.

**Pregătire:** un exemplu cu două personaje și blocul de pornire la atingere. Pentru demonstrație putem folosi o săritură sau o mișcare cunoscută.

**Împreună:** anticipăm dacă personajul va reacționa la steagul verde sau la atingere. Testăm cele două situații.

1. **Exercițiul 1 — Atinge și descoperă:** fă un personaj să execute o acțiune când îl atingi.
2. **Exercițiul 2 — Două surprize:** al doilea personaj răspunde la atingere cu o altă secvență. Un coleg încearcă ambele.
3. **Provocare:** adaugă un al treilea personaj cu propria reacție.

**Verificare:** atingerea unui personaj pornește reacția pregătită pentru el. Copilul explică ce anume pornește programul.

**Sprijin:** folosim o singură secvență pentru fiecare personaj. La testare, atingem o dată și așteptăm finalul acțiunii. Pentru variația personală, copilul alege o surpriză, nu doar alt fundal.

## Lecția 5 Adăugăm sunete

**Ideea:** sunetul poate fi o acțiune din program.

**Pregătire:** verificăm sunetul Pop inclus în aplicație și volumul. Microfonul și înregistrarea nu sunt necesare.

**Împreună:** un personaj pornește la atingere și redă un sunet. Apoi adăugăm o mișcare și observăm ordinea acțiunilor.

1. **Exercițiul 1 — Animalul se aude:** la atingere, personajul redă sunetul Pop din aplicație.
2. **Exercițiul 2 — Sunet și mișcare:** construiește o secvență cu sunet și mișcare. Schimbă ordinea și observă ce diferă.
3. **Provocare:** creează două ritmuri diferite folosind Pop și mișcări. Opțional, inventează un sunet cu înregistratorul din aplicație.

**Verificare:** copilul pornește sunetul prin program și poate arăta locul lui în secvență.

**Sprijin:** folosim Pop, la volum moderat, și secvențe scurte. Nu cerem sunete de animale descărcate sau text scris.

## Lecția 6 Personajele își așteaptă rândul

**Ideea:** așteptarea schimbă momentul unei acțiuni.

**Pregătire:** două personaje, fiecare cu o săritură și, opțional, Pop. Profesorul pregătește un exemplu în care reacțiile se suprapun.

**Împreună:** doi copii spun ceva simultan, apoi pe rând. În aplicație, ambele personaje pornesc la steagul verde, dar al doilea așteaptă înainte de a răspunde. Reglăm durata prin observare.

1. **Exercițiul 1 — Răspunsul întârziat:** primul personaj sare, iar al doilea așteaptă înainte de propria săritură.
2. **Exercițiul 2 — Construim dialogul:** creează câte o secvență pentru fiecare personaj și alege așteptarea astfel încât săriturile să aibă loc pe rând. Ajustările se fac după testarea propriei creații.
3. **Provocare:** după ce răspunde, al doilea personaj face o mișcare.

**Verificare:** replicile sau acțiunile sunt distincte, iar copilul identifică blocul care amână răspunsul.

**Sprijin:** folosim două acțiuni scurte, vizibile, fără înregistrări obligatorii. Valorile blocului se ajustează pe exemplul profesorului; nu cerem calcule de timp. Dacă sunetul este dificil de urmărit, înlocuim replicile cu două mișcări succesive.

## Lecția 7 Predăm ștafeta cu un mesaj

**Ideea:** un personaj poate trimite un semnal care pornește programul altuia.

**Pregătire:** două personaje, o singură culoare de mesaj și un exemplu foarte scurt. În jocul fără tabletă, un copil oferă altuia un cartonaș colorat pentru a-i da rândul.

**Împreună:** primul personaj pornește la steagul verde, se mișcă și trimite un mesaj. Al doilea începe când primește mesajul de aceeași culoare.

1. **Exercițiul 1 — Ștafeta:** construiește legătura dintre expeditor și destinatar. Al doilea personaj execută o mișcare după semnal.
2. **Exercițiul 2 — Ștafeta cu două probe:** construiește o secvență în care primul personaj merge și sare înainte să trimită mesajul, iar al doilea răspunde cu două acțiuni alese de copil. Reușită: al doilea începe după încheierea probei primului.
3. **Provocare:** adaugă o acțiune înainte de trimiterea mesajului și observă cum se schimbă începutul celuilalt personaj.

**Verificare:** copilul arată cine trimite, cine primește și de ce trebuie să se potrivească semnalul.

**Sprijin:** pornim cu un singur mesaj, într-o singură direcție. Dacă grupa nu este pregătită, păstrăm demonstrația, apoi consolidăm scenele pornite prin atingere. Folosirea mesajelor nu devine o condiție pentru proiectul final.

## Lecția 8 O poveste în două pagini

**Ideea:** o poveste poate avea două scene legate între ele.

**Pregătire:** o poveste vizuală foarte scurtă, de exemplu „Pleacă de acasă” și „Ajunge în parc”. Profesorul arată cum se adaugă și se selectează o pagină și cum se folosește blocul de trecere la pagina aleasă.

**Împreună:** desenăm două cadre și spunem oral ce se întâmplă întâi și ce urmează.

1. **Exercițiul 1 — Prima scenă:** la atingerea personajului, acesta face o scurtă mișcare; la final, programul trece la pagina a doua.
2. **Exercițiul 2 — Finalul poveștii:** pe pagina a doua, copilul pregătește o reacție pornită prin atingere și testează povestea de la început.
3. **Provocare:** adaugă o reacție sonoră sau, dacă primele două pagini funcționează, o a treia scenă.

**Verificare:** copilul parcurge cele două pagini în ordinea intenționată și spune unde începe și unde se termină povestea.

**Sprijin:** nu presupunem că un personaj sau programul lui se transferă automat pe pagina nouă; pregătim fiecare scenă. Limităm decorarea și verificăm că blocul de schimbare indică pagina dorită.

## Lecția 9 Construim proiectul nostru

**Ideea:** alegem un rezultat, îl împărțim în pași și construim prima versiune.

**Alegerea proiectului:** copilul poate realiza o poveste, o scenă cu surprize la atingere sau un dans. Poate continua un proiect propriu din lecțiile precedente.

**Cerințe de bază:** cel puțin un personaj, un mod clar de pornire, o secvență cu cel puțin două acțiuni și o alegere personală în comportamentul proiectului. Două personaje, repetițiile, sunetele, mesajele și paginile suplimentare sunt opțiuni.

| Interval | Activitate |
| --- | --- |
| 0–5 min | Vedem două exemple și alegem tipul proiectului |
| 5–10 min | Desenăm sau explicăm ce se întâmplă întâi și apoi |
| 10–22 min | Construim comportamentul principal |
| 22–25 min | Pauză de mișcare |
| 25–40 min | Completăm proiectul și îl testăm |
| 40–45 min | Un coleg încearcă și oferă o observație |
| 45–50 min | Verificăm salvarea și alegem ce mai lucrăm data viitoare |

1. **Exercițiul 1 — Prototipul:** construiește o singură interacțiune care funcționează.
2. **Exercițiul 2 — O completare:** adaugă încă o reacție sau un pas al poveștii și testează din nou.
3. **Provocare:** folosește un mecanism deja cunoscut pentru a face proiectul mai expresiv.

**Verificare:** există o versiune funcțională și copilul poate spune ce mai dorește să schimbe. Nu introducem blocuri noi.

**Sprijin:** oferim trei idei vizuale de pornire și o fișă cu două cadre. Profesorul ajută copilul să micșoreze proiectul dacă ideea este prea mare pentru timpul disponibil.

## Lecția 10 Testăm îmbunătățim și prezentăm

**Ideea:** un proiect devine mai clar când îl încearcă și altcineva.

**Pregătire:** fiecare copil primește aceeași tabletă și redeschide proiectul din lecția 9. Profesorul pregătește un exemplu de feedback: „Am apăsat aici și am văzut asta. Așa ai vrut?”.

| Interval | Activitate |
| --- | --- |
| 0–5 min | Redeschidem proiectele și alegem o îmbunătățire |
| 5–17 min | Completăm și reparăm |
| 17–25 min | Testăm în perechi, pe rând |
| 25–28 min | Pauză de mișcare |
| 28–38 min | Aplicăm o îmbunătățire și verificăm rezultatul |
| 38–47 min | Prezentări în grupuri mici și câteva exemple pentru clasă |
| 47–50 min | Verificăm salvarea și încheiem cursul |

1. **Exercițiul 1 — Testul colegului:** colegul încearcă proiectul, iar autorul observă dacă reacțiile sunt cele dorite.
2. **Exercițiul 2 — O îmbunătățire:** repară un bloc, ajustează o așteptare sau face mai clar locul de pornire.
3. **Provocare:** explică o secvență sau adaugă un detaliu care nu împiedică funcționarea proiectului.

**Verificare:** copilul demonstrează cum pornește proiectul, explică o parte a programului și spune ce a schimbat. Ajutorul primit nu anulează reușita.

**Sprijin:** fiecare copil arată proiectul unui coleg sau unui grup mic; nu depindem de timpul necesar unor prezentări individuale în fața întregii clase. Copilul poate explica prin gesturi și arătarea blocurilor.

## Pregătirea tabletelor și a clasei

Înainte de prima întâlnire:

- Instalăm ScratchJr pe o tabletă K10 și testăm tragerea blocurilor, sunetul, salvarea, redeschiderea și exportul unui proiect mic.
- Testăm pornirea aplicației și redeschiderea proiectului fără internet. Facem proba pe configurația reală a școlii.
- Folosim tabletele în poziție orizontală, încărcate, cu luminozitate și volum potrivite.
- Numerotăm tabletele și păstrăm, pe cât posibil, aceeași repartizare la fiecare întâlnire. Profesorul poate denumi proiectele simplu, de exemplu „L01 Joacă”; numele automat și miniatura sunt suficiente pentru copiii care încă nu scriu.
- Pregătim modul în care profesorul arată aplicația clasei. Verificăm proiecția sau folosim exemple vizuale pregătite în avans.
- Pregătim cartonașe cu pictogramele blocurilor și foi pentru desenarea unei secvențe, utile și dacă o tabletă nu funcționează.

Proiectele ScratchJr se salvează local pe dispozitiv. Profesorul stabilește o rutină de export pentru proiectele importante, în special după lecțiile 9 și 10. Dezinstalarea aplicației poate duce la pierderea lucrărilor; nu ștergem datele între întâlniri. [Salvarea și exportul proiectelor în ScratchJr](https://mitscratch.freshdesk.com/en/support/solutions/articles/4000211814-how-can-i-save-or-export-my-project-on-scratchjr-)

La fiecare final de lecție, revenim la galeria proiectelor și verificăm că lucrarea poate fi regăsită. Profesorul notează scurt ce a fost ușor, unde s-au blocat copiii și ce merită reluat.

## Materialele de pregătit pentru fiecare lecție

Pentru fiecare întâlnire pregătim același pachet:

- O fișă pentru profesor: obiectiv, demonstrație, întrebări, dificultăți probabile și criteriul de reușită.
- Două cartonașe vizuale pentru exercițiile de bază, cu o cerință scurtă și rezultatul așteptat.
- Un cartonaș cu exercițiul dificil, ținta observabilă și indicii progresive; este inclus în fiecare lecție și prezentat tuturor.
- Un proiect demonstrativ opțional pe dispozitivul profesorului și pașii de construire din biblioteca aplicației. Nu distribuim proiecte de pornire pe tabletele copiilor.
- Întrebări și indicii pentru dificultățile care apar în proiectele construite de copii; nu pregătim programe greșite pe care copiii să le copieze.
- O observație scurtă după predare, pentru ajustarea întâlnirii următoare.

Cartonașele arată ce trebuie să se întâmple. Programul complet este demonstrat numai când ajută învățarea. Copilul are loc să aleagă și să încerce.

## Rolul siteului Robo Explorator

Siteul poate deveni suportul în limba română al cursului, cu trei intrări:

- **Cursul ScratchJr cu 10 lecții:** explicații vizuale, exerciții, provocări și note pentru profesor.
- **Școala altfel și activitățile originale:** colecția Robo deja parcursă, păstrată separat.
- **Acasă cu Robo:** activitățile existente pentru acasă.

Programarea se face în aplicația ScratchJr de pe tabletă. Siteul prezintă cerințele și exemplele; nu presupunem că poate citi sau verifica automat proiectele ScratchJr. Reușita se verifică prin demonstrație și discuție.

Acest plan stabilește conținutul cursului. Pachetul lecției 1 este pregătit în [Lectia_01_ScratchJr](Lectia_01_ScratchJr/README.md), cu ghid, cartonașe și proiecte native. Lecția 2 este pregătită în [Lectia_02_ScratchJr](Lectia_02_ScratchJr/README.md), cu misiuni de construire și exercițiu dificil. Lecția 3 este pregătită în [Lectia_03_ScratchJr](Lectia_03_ScratchJr/README.md), cu curse, depășire și două rezerve. Materialele lecțiilor 4-10 și noul meniu urmează să fie realizate; observațiile din primele două întâlniri vor regla dificultatea celorlalte.

## Referințe pentru pregătirea profesorului

Mecanismele folosite în curs corespund blocurilor ScratchJr pentru mișcare, evenimente, sunet, așteptare, repetare, mesaje și pagini. [Cartonașele oficiale cu blocuri ScratchJr](https://www.scratchjr.org/pdfs/blocks.pdf) pot servi drept reper pentru pictograme.

[Îndrumarul oficial despre salvare și export](https://mitscratch.freshdesk.com/en/support/solutions/articles/4000211814-how-can-i-save-or-export-my-project-on-scratchjr-) susține rutina de păstrare a proiectelor. Ordinea lecțiilor, exercițiile și ritmul de mai sus sunt propuse pentru această grupă, pornind de la experiența ei cu Robo Explorator.
